from django.contrib import admin
from .models import NewsArticle

#Register models
admin.site.register(NewsArticle)
