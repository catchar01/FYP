import re
import nltk
from nltk.corpus import stopwords
nltk.download('stopwords')
nltk.download('punkt')
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import csv

CSV_FILE_PATH = "Loughran-McDonald_MasterDictionary_1993-2023.csv"

def load_lm(file_path):
    sentiment_dict = {}
    with open(file_path, mode='r', encoding='utf-8-sig') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            word = row["Word"].upper()
            sentiment_dict[word] = {
                "Negative": 1 if int(row["Negative"]) > 0 else 0,
                "Positive": 1 if int(row["Positive"]) > 0 else 0,
                "Uncertainty": 1 if int(row["Uncertainty"]) > 0 else 0,
                "Litigious": 1 if int(row["Litigious"]) > 0 else 0,
                "StrongModal": 1 if int(row["Strong_Modal"]) > 0 else 0,
                "WeakModal": 1 if int(row["Weak_Modal"]) > 0 else 0,
                "Constraining": 1 if int(row["Constraining"]) > 0 else 0,
            }
    return sentiment_dict

sentiment_dict = load_lm("Loughran-McDonald_MasterDictionary_1993-2023.csv")
stop_words = set(stopwords.words('english'))

#custom list of financial stopwords
finance_stop_words = {'company', 'companies', 'said', 'us', 'financial', 'business', 'year', 'one', 'stock'}
stop_words.update(finance_stop_words)

#removing stopwords that I want to analyse
to_keep = {'increase', 'decrease', 'loss', 'gain'}
stop_words = stop_words - to_keep

def clean_text(text):
    text = text.lower()
    text = re.sub(r'<.*?>', '', text)
    text = re.sub(r'http\S+|www\.\S+', '', text)
    text = re.sub(r'[\d]', '', text)  #Remove numbers
    text = re.sub(r"[^\w\s]", '', text)  #Removes all punctuation 
    text = re.sub(r'\s+', ' ', text).strip()
    text = ' '.join([word for word in text.split() if word not in stop_words])
    return text

analyser = SentimentIntensityAnalyzer()
def sent_score(text):
    cleaned_text = clean_text(text).upper()
    words = cleaned_text.split()

    #Init score from VADER
    vs = analyser.polarity_scores(cleaned_text)
    vader_score = vs['compound']

    lm_score_adjustments = 0
    for word in words:
        if word in sentiment_dict:
            if sentiment_dict[word]["Negative"]:
                lm_score_adjustments -= 1
            if sentiment_dict[word]["Positive"]:
                lm_score_adjustments += 1

    #Combine VADER score with +Loughran-McDonald
    combined_score = vader_score + (lm_score_adjustments * 0.1)
    return combined_score, cleaned_text