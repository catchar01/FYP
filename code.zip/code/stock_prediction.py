import os
import django
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sentiments_stock_data import get_stock_data
from collections import defaultdict
from datetime import datetime

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'take2.settings')
django.setup()

from newsapp.models import NewsArticle

def prepare_data_with_sentiments(stock_symbol, forecast_out=1):
    split_date = pd.Timestamp(datetime.now().date())
    stock_data = get_stock_data(stock_symbol)

    #aggregate daily sentimetns by stock
    articles = NewsArticle.objects.all()
    daily_scores_by_stock = defaultdict(lambda: defaultdict(list))
    
    for article in articles:
        date_str = article.published_at.date().strftime('%Y-%m-%d')
        daily_scores_by_stock[stock_symbol][date_str].append(article.sentiment_scores)
    
    #average sentiment score for each day for each stock
    daily_avg_scores_by_stock = {}
    for stock, dates in daily_scores_by_stock.items():
        daily_avg_scores_by_stock[stock] = {
            date: sum(scores) / len(scores) for date, scores in dates.items() if scores
        }

    sentiments = daily_avg_scores_by_stock
    stock_data.index = pd.to_datetime(stock_data.index)
    sentiment_scores = pd.DataFrame(list(sentiments[stock_symbol].items()), columns=['Date', 'Sentiment'])
    sentiment_scores['Date'] = pd.to_datetime(sentiment_scores['Date'])
    sentiment_scores.set_index('Date', inplace=True)

    combined_data = pd.merge(stock_data, sentiment_scores, how='left', left_index=True, right_index=True)
    combined_data['Sentiment'].fillna(0, inplace=True)
    combined_data['Prediction'] = combined_data['Close'].shift(-forecast_out)

    train = combined_data.loc[combined_data.index < split_date]
    test = combined_data.loc[combined_data.index >= split_date]

    return train, test

def predict_stock_prices_with_sentiment(stock_symbol, forecast_out=1):#do i need tomake this date the current date??
    train, test = prepare_data_with_sentiments(stock_symbol, forecast_out)

    X_train = train.drop(['Close', 'Prediction'], axis=1)
    y_train = train['Close'].shift(-forecast_out).dropna()

    X_train = X_train[:-forecast_out]
    y_train = y_train.dropna()

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)

    model = LinearRegression()
    model.fit(X_train_scaled, y_train)

    #Predict using data from last day in training set
    X_last_days = train.tail(forecast_out).drop(['Close', 'Prediction'], axis=1)
    X_last_days_scaled = scaler.transform(X_last_days)
    predictions = model.predict(X_last_days_scaled)
    #correlation
    correlation = train[['Sentiment', 'Prediction']].corr().iloc[0, 1]
    print(f"Correlation between Sentiment and Stock Prediction: {correlation}")

    print(f"tomorrow {predictions}") #make to 2 dp?

    return predictions

if __name__ == '__main__':
    predict_stock_prices_with_sentiment('MSFT', forecast_out=1)